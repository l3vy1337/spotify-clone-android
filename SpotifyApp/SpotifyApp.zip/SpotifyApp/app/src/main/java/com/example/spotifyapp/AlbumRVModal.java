package com.example.spotifyapp;

public class AlbumRVModal {
    public String albumType;
    public String albumName;
    public String external_ids;
    public String external_urls;
    public String href;
    public String id;
    public String imageUrl;
    public String label;
    public String name;
    public int popularity;
    public String releaseDate;
    public int totalTracks;
    public String type;

    public AlbumRVModal(String albumType, String albumName, String external_ids, String external_urls, String href, String id, String imageUrl, String label, String name, int popularity, String releaseDate, int totalTracks, String type) {
        this.albumType = albumType;
        this.albumName = albumName;
        this.external_ids = external_ids;
        this.external_urls = external_urls;
        this.href = href;
        this.id = id;
        this.imageUrl = imageUrl;
        this.label = label;
        this.name = name;
        this.popularity = popularity;
        this.releaseDate = releaseDate;
        this.totalTracks = totalTracks;
        this.type = type;
    }
}
